
public class PagedQuery
{
    public int pageNumber { get; set; }
    public int count { get; set; } = 10;
    public string minDate { get; set; }
}